function displayMessage() {
    alert('Amico invitato!');
  }
  